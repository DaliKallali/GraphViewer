/**
 * Various builder for graphs.
 */
package org.jgrapht.graph.builder;

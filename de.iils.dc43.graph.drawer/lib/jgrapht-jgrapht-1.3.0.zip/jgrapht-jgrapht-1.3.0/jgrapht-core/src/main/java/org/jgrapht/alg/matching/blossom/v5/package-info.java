/**
 * Package for Kolmogorov's Blossom V algorithm
 */
package org.jgrapht.alg.matching.blossom.v5;

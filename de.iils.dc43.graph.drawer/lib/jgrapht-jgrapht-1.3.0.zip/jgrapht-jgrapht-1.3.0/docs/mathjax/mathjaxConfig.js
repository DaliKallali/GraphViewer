MathJax.Hub.Config({
  tex2jax: {
    inlineMath: [['$','$'], ['\\(','\\)']],
    processEscapes: true
  }
});
MathJax.Ajax.loadComplete("https://jgrapht.org/mathjax/mathjaxConfig.js");
